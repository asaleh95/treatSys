<template>
  <div class="header-section">
    <div class="container-fluid">
      <div class="row justify-content-between align-items-center">
        <!-- Header Logo (Header Left) Start -->
        <div class="header-logo col-auto">
          <li>
            <img
              style="margin-bottom: 41px; border-radius: 2.25rem !important"
              src="/Web/treat2.png"
              class="mx-auto d-block"
              alt="سله"
              width="80"
              height="70"
            />
          </li>
        </div>
        <!-- Header Logo (Header Left) End -->

        <!-- Header Right Start -->
        <div class="header-right flex-grow-1 col-auto">
          <div class="row justify-content-between align-items-center">
            <!-- Side Header Toggle & Search Start -->
            <search></search>

            <!-- Header Notifications Area Start -->
            <notification></notification>
          </div>
        </div>
        <!-- Header Right End -->
      </div>
    </div>
  </div>
  <!-- Header Section End -->
</template>
