<template>
    <div class="footer-section footer">
            <div class="container-fluid">

                <div class="footer-copyright text-center">
                    <p style="    font-family: sans-serif;" class="text-body-light">2021 &copy; <a >Treat</a></p>
                </div>

            </div>
        </div><!-- Footer Section End -->
</template>

<style>
.footer{
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
}
</style>