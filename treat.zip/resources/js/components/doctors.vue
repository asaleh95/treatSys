<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <div class="row head">
        <h4>Doctors</h4>
        <h5 class="head2">
          | <a class="user" href="#"><img src="Web/home.png" alt="" /></a>>>
          7,618 results found in 5ms
        </h5>
        <a href="#"><img src="Web/search+.png" alt="" /></a>
        <a href="#"><img src="Web/search+.png" alt="" /></a>
      </div>
      <br /><br />
      <div class="row">
        <h3 class="log mr-auto"><span>Ex : Doctor Name</span></h3>
        <a class="search" href="#"><img src="Web/gro.png" alt="" /></a>
        <a class="search" href="#"><img src="Web/gro2.png" alt="" /></a>
      </div>
      <hr />
      <div class="content">
        <div class="row">
          <div class="col-md-2 hospital">
            <img src="Web/11.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/14.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/13.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/12.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/20.png" class="doctor" alt="" />
          </div>
        </div>
        <div class="row">
          <div class="col-md-2 hospital">
            <img src="Web/11.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/14.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/13.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/12.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/20.png" class="doctor" alt="" />
          </div>
        </div>
      </div>
      <br /><br />
      <div class="row mb-5">
        <div class="col-md-12 d-flex justify-content-center">
          <a href="#" class="btn btn-light rounded-circle"><</a>
          <a href="#" class="btn rounded-circle">4</a>
          <a href="#" class="btn rounded-circle">3</a>
          <a href="#" class="btn rounded-circle">2</a>
          <a href="#" class="btn btn-primary rounded-circle mr-2">1</a>
          <a href="#" class="btn btn-light rounded-circle">></a>
        </div>
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>