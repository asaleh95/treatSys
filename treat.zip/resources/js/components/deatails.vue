<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <treat-header
        name="Hospitals"
        header="Dar Al Fouad Hospital 
"
      ></treat-header>
      <div class="row">
        <div class="col-md-8 col-sm-8">
          <img src="Web/hos.png" alt="" class="img0" />
          <div class="row maxWidth">
            <img src="Web/22.png" alt="" class="col-md-2 col-sm-2" />
            <img src="Web/77.png" alt="" class="col-md-2 col-sm-2" />
            <img src="Web/88.png" alt="" class="col-md-2 col-sm-2" />
            <img src="Web/99.png" alt="" class="col-md-2 col-sm-2" />
            <img src="Web/99.png" alt="" class="col-md-2 col-sm-2" />
          </div>
        </div>
        <div class="col-md-4 col-sm-4">
          <p class="font-b">Cairo , Ain Shams</p>
          <h4 class="font-weight-bold">Dar Al Fouad Hospital</h4>
          <p class="set0">(15,250)</p>
          <h6 class="font-weight-bold">
            <img src="Web/images.png" alt="" class="logo0" />
            <span> Dar Al Fouad Hospital Logo</span>
          </h6>

          <br /><br />
          <h6 class="font-weight-bold">
          <img src="Web/gwab.png" alt="" />
          <span> DarAlFouad@gmail.com</span>
          </h6>
          <br /><br />
          <h6 class="font-weight-bold">
            <img src="Web/phone.png" alt="" /><span class="num">+20</span>
            1019917043
          </h6>
          <br />
          <div>
            <h6 class="font-weight-bold">
              <img src="Web/pin.png" alt="" /> Mozia Art Space and Cafe
            </h6>
            <p class="font-b">14 Phan huy ich, Bo Durh, Hanai</p>
          </div>
        </div>
      </div>
      <br />
      <div class="row">
        <h3 class="font-weight-bold">about</h3>
        <p class="font-b">
          It is a long established fact that a reader will be distracted by the
          readable content of a page when looking at its layout. The point of
          using Lorem Ipsum is that it has a more-or-less normal distribution of
          letters, as opposed to using 'Content here, content here', making it
          look like readable English. Many desktop publishing packages and web
          page editors now use Lorem Ipsum as their default model text, and a
          search for 'lorem ipsum' will uncover many web sites still in their
          infancy. Various versions have evolved over the years, sometimes by
          accident, sometimes on purpose (injected humour and the like).
        </p>
        <br />
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>