
<template>
  <div class="row">
    <div class="col-md-4 pl-5 pt-5">
      <h1 class="logi">HELP!</h1>
      <br />
      <h4>Forgot Password!</h4>
      <br />
      <p class="text-muted font-b">
        There are many variations of passages of Lorem Ipsum available, some
        form .
      </p>
      <br />
      <br />
      <form action="" class="form-inline">
        <div class="row">
          <input
            type="text"
            class="form-control text-center input-number ml-2 font-b"
            placeholder="0"
            name=""
            id=""
          />
          <input
            type="text"
            class="form-control text-center input-number ml-2 font-b"
            placeholder="0"
            name=""
            id=""
          />
          <input
            type="text"
            class="form-control text-center input-number ml-2 font-b"
            placeholder="0"
            name=""
            id=""
          />
          <input
            type="text"
            class="form-control text-center input-number ml-2 font-b"
            placeholder="0"
            name=""
            id=""
          />
          <input
            type="text"
            class="form-control text-center input-number ml-2 font-b"
            placeholder="0"
            name=""
            id=""
          />
        </div>
        <br />
        <br />
        <button type="button" class="submit text-white font-weight-bold">Done</button>
      </form>
      <br />
      <br />
      <p class="text-muted text-center">
        i don't receive emails ! <a href="#"> Resend</a>
      </p>
    </div>
    <div class="col-md-8">
      <img
        src="/Web/5.png"
        class="img-fluid w-100 back-color"
        alt="Cinque Terre"
      />
      <img
        src="/Web/55.png"
        class="topleft"
        style="width: 110%"
        alt="over-image"
      />
      <div>
        <h1 class="center">We Trust</h1>
        <h1 class="center text-t7t">We Care</h1>
      </div>
    </div>
  </div>
</template>