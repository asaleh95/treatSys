<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <treat-header name="Blog/News" header="Large article title"></treat-header>
      <div class="row mt-4 mb-5">
        <div class="col-md-5 col-sm-5 border-right">
          <h3 class="mb-4 quis">Quisque viverra interdum velit?</h3>
          <p class="font-b">
            Lorem ipsum dolor sit amet consectetur adipiscing elit sodales
            primis, mollis viverra conubia ligula inceptos laoreet libero
            tortor, nascetur non habitasse iaculis tempor nec egestas fames
            augue, platea porta integer nostra curae sed arcu. Nec ut diam
            vulputate ante scelerisque ridiculus lobortis orci mi curae
            himenaeos quis, senectus curabitur ullamcorper a porttitor nibh
            fermentum nisi cum morbi aliquam. Vitae pretium vestibulum dui
            gravida in potenti interdum, class rhoncus neque.
          </p>
          <p class="font-b">
            Ullamcorper porttitor non pharetra cursus nisl mollis pellentesque
            primis penatibus platea, dictum himenaeos eget mi bibendum ad
            molestie aliquet curae quis quisque, nunc duis ac at elementum dui
            integer viverra tempus. Lacinia bibendum diam senectus egestas nec
            molestie convallis aenean hac tempus, vivamus purus congue euismod
            fringilla cursus donec est eu blandit platea, feugiat vitae netus
            orci habitant accumsan placerat morbi nostra. Quam fringilla sociis
            suspendisse quis ultricies dis tellus cum, litora aliquet.
          </p>
          <hr class="margin-top-p" />
          <h4 class="sma">Small Title - Subtitle</h4>
          <p class="font-b">3h ago by Worldnews</p>
        </div>
        <div class="col-md-7 col-sm-7">
          <div class="row container mb-3">
            <img
              src="/Web/avatar.png"
              class="rounded-circle img-start mr-3"
              alt=""
            />
            <h3 class="jon">Jonathan Walker</h3>
            <p>
              In hac habitasse platea dictumst. Sed nec venenatis odio. Nulla
              faucibus ipsum sed faucibus accumsan. Donec rhoncus luctus massa
              vitae lobortis. Duis consequat, nunc a pretium imperdiet, neque
              est rhoncus massa, tristique rutrum nisl risus at libero.
            </p>
          </div>
          <div class="row container mb-3">
            <img
              src="/Web/amd.png"
              class="rounded-circle img-start mr-3"
              alt=""
            />
            <h3 class="jon">Brenda Mercer</h3>
            <br />
            <p>
              In hac habitasse platea dictumst. Sed nec venenatis odio. Nulla
              faucibus ipsum sed faucibus accumsan. Donec rhoncus luctus massa
              vitae lobortis. Duis consequat, nunc a pretium imperdiet, neque
              est rhoncus massa, tristique rutrum nisl risus at libero.
            </p>
          </div>
          <div class="row container mb-3jo">
            <img
              src="/Web/avatar.png"
              class="rounded-circle img-start mr-3"
              alt=""
            />
            <h3 class="jon">Brenda Mercer</h3>
            <p>
              Lorem ipsum dolor sit amet consectetur adipiscing elit sodales
              primis, mollis viverra conubia ligula inceptos laoreet libero
              tortor, nascetur non habitasse iaculis tempor nec egestas fames
              augue, platea porta integer nostra curae sed arcu. Nec ut diam
              vulputate ante scelerisque ridiculus lobortis orci mi curae.
            </p>
            <img src="Web/img.png" class="img-fluid" />
          </div>
        </div>
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>