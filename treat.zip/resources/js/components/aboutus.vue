<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <treat-header name="AboutUs"></treat-header>
      <div class="row">
        <img src="/Web/hand.png" class="img-fluid" alt="" />
      </div>
      <div class="row mt-4 mb-5">
        <div class="col-md-6 col-sm-6">
          <h2>It’s time to listen to the ones who know be</h2>
          <p>
            a This is a descriptive sub-headline that introduces the whole
            content of this text to the audience who is interested in reading
            about this top
          </p>
          <p>
            Text Default dolor sit amet, consetetur sadipscing elitr, sed diam
            nonumy eirmod tempor invidunt ut Lorem ipsum dolor sit amet,
            consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
            ut labore et dolore magna aliquyam erat, sed dia. Hui ipsum dolor
            sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor
            invidunt ut labore et dolore magna aliquyam erat, sed dia.Text
            Default Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
            diam nonumy eirmod tempor invidunt ut labore et dolore magna
            aliquyam erat, sed
          </p>
        </div>
        <div class="col-md-6 col-sm-6">
        <img src="\Web\15.png" class="st-fo2" alt="">
        </div>
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>