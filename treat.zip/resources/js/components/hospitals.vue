<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <div class="row head">
        <h4>Hospital</h4>
        <h5 class="head2">
          | <a class="user" href="#"><img src="Web/home.png" alt="" /></a>>>
          Many results found
        </h5>
        <a href="#"><img src="Web/search+.png" alt="" /></a>
        <a href="#"><img src="Web/search+.png" alt="" /></a>
      </div>
      <br /><br />
      <div class="row">
        <h3 class="log mr-auto"><span>Ex : Doctor Name</span></h3>
        <a class="search" href="#"><img src="Web/gro.png" alt="" /></a>
        <a class="search" href="#"><img src="Web/gro2.png" alt="" /></a>
      </div>
      <hr />
      <div class="content">
        <div class="row">
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          <div class="card col-2 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
      </div>
      <br /><br />
      <div class="row mb-5">
        <div class="col-md-12 d-flex justify-content-center">
          <a href="#" class="btn btn-light rounded-circle"><</a>
          <a href="#" class="btn rounded-circle">4</a>
          <a href="#" class="btn rounded-circle">3</a>
          <a href="#" class="btn rounded-circle">2</a>
          <a href="#" class="btn btn-primary rounded-circle mr-2">1</a>
          <a href="#" class="btn btn-light rounded-circle">></a>
        </div>
      </div>
    </div>
    <footer class="footer-b">
      <div class="row footer-row">
        <div class="offset-md-1 col-2">
          <img src="Web/treat.png" alt="" />
        </div>
        <div class="col-2">
          <ul class="list-unstyled text-small">
            <li>Commuinity</li>
            <li>Create Account</li>
            <li>Go to Premium</li>
            <li>Prefer A Friend</li>
            <li>Get Coupon Code</li>
          </ul>
        </div>
        <div class="col-2">
          <ul class="list-unstyled text-small">
            <li>Support</li>
            <li>Terms Condition</li>
            <li>Privacy & Policy</li>
            <li>Copyright Issue</li>
            <li>Get Help</li>
          </ul>
        </div>
        <div class="col-2">
          <ul class="list-unstyled text-small">
            <li>Join Us</li>
            <li>Become Teacher</li>
            <li>Become Student</li>
            <li>Become Both</li>
            <li>Partnership</li>
          </ul>
        </div>
        <div class="col-2">
          <ul class="list-unstyled text-small">
            <li>download app</li>
            <li></li>
          </ul>
          <button type="button" class="btn btn-info">google play</button>
          <br /><br />

          <button type="button" class="btn btn-info">app ios</button>
        </div>
      </div>
    </footer>
    <div class="row">
      <small class="d-block mb-3 text-muted offset-md-2"
        >&copy; Copyright © 2010-2019 Pro.skill</small
      >
      <small class="d-block mb-3 text-muted offset-md-6">Go to To</small>
    </div>
  </div>
</template>