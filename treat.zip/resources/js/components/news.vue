<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
      <treat-header name="News" header="TRENDING"></treat-header>
      <div class="row">
        <div class="col-md-9 col-sm-8">
          <img src="/Web/hero.png" class="img-fluid" alt="" />
          <div class="carousel-caption caption mb-2">
            <h4 class="text-left text-WHITE">WORLD NEWS</h4>
            <!-- <hr class="mt-5 text-white" /> -->
            <div class="mt-5 border-top">

            </div>
            <h5 class="mt-5 text-left"> Amazing places in America to visi</h5>
            <p class="text-left">
              For some reason — this country, this city, this neighborhood, this
              particular street —  is the place you are living a majority of
              your life
            </p>
            <button class="btn btn-info float-left"> LEARN More</button>
          </div>
        </div>
        <div class="col-md-3 col-sm-4">
          <h6 class="mt-md-5 text-lg-3 font-weight-bold">
            MORE NEWS
            <img
              src="/Web/asset1.png"
              class="img-fluid float-right arrow-news-20"
              alt=""
            />
          </h6>
          <hr />
          <div>
            <h5 class="text-info">TRAVEL</h5>
            <h6>Article title</h6>
            <p class="paragraph-news">
              e Lorem ipsum dolor sit amet, ipsum labitur luciliu
            </p>
            <p class="text-muted">
              <span
                ><i class="fa fa-clock-o" aria-hidden="true"></i> 2 min a</span
              >
            </p>
          </div>
          <div>
            <h5 class="text-info">TRAVEL</h5>
            <h6>Article title</h6>
            <p class="paragraph-news">
              e Lorem ipsum dolor sit amet, ipsum labitur luciliu
            </p>
            <p class="text-muted">
              <span
                ><i class="fa fa-clock-o" aria-hidden="true"></i> 2 min a</span
              >
            </p>
          </div>
        </div>
      </div>
      <div><h5 class="bottom">TRENDING</h5></div>
      <div class="row">
        <div class="col-md-3 top">
          <img src="/Web/image.png" class="w-100" alt="" />
          <h6>Dolore magna aliq</h6>
          <p class="paragraph-news">
            a Lorem ipsum dolor sit amet, ipsum labitu
          </p>
        </div>
        <div class="col-md-3 top">
          <img src="/Web/reception.png" class="w-100" alt="" />
          <h6>Morbi eleifend a libero</h6>
          <p class="paragraph-news">
            Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad has
            appareat.
          </p>
        </div>
        <div class="col-md-3 top">
          <img src="/Web/doc.png" class="w-100" alt="" />
          <h6>Morbi eleifend a libero</h6>
          <p class="paragraph-news">
            Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad has
            appareat.
          </p>
        </div>
        <div class="col-md-3 top">
          <img src="/Web/kmama.png" class="w-100" alt="" />
          <h6>Morbi eleifend a libero</h6>
          <p class="paragraph-news">
            Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad has
            appareat.
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <img src="Web/sss.png" class="img-fluid" alt="" />
          <h6>Morbi eleifend a libero</h6>
          <p class="paragraph-news">
            Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad has
            appareat.
          </p>
          <img src="Web/aaa.png" class="img-fluid" alt="" />
          <h6>Morbi eleifend a libero</h6>
          <p class="paragraph-news">
            Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad has
            appareat.
          </p>
        </div>

        <div class="col-md-6">
          <div class="row">
            <div class="col-md-6">
              <img src="Web/jjj.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
            <div class="col-md-6">
              <img src="Web/bed.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
          </div>
          <div class="row">
            
            <div class="col-md-6">
              <img src="Web/jjj.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
            <div class="col-md-6">
              <img src="Web/bed.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <img src="Web/jjj.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
            <div class="col-md-6">
              <img src="Web/bed.png" class="w-100" alt="" />
              <h6>Morbi eleifend a libero</h6>
              <p class="paragraph-news">
                Lorem ipsum dolor sit amet, ipsum labitur lucilius mel id, ad
                has appareat.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>