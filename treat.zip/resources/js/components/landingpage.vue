<template>
  <div>
    <div class="container">
      <treat-nav></treat-nav>
    
      <div class="row mb-5 mt-5">
        <!-- left side  => form -->
        <!-- image -->
        <div class="col-12">
          <div class="contain">
            <img
              src="/Web/5.png"
              class="img img-responsive land"
              alt="main-image"
            />
            <img src="/Web/55.png" class="centered img-g" alt="over-image" />
            <div>
              <h2 class="text-center">learn new</h2>
              <p class="ten">everyday</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-5">
        <div class="col-md-2 border rounded-sm border-corner">
          <img src="Web/sma3a.png" class="mx-auto d-block mt-5" alt="" />
          <h6 class="offset-3 mt-3">doctors</h6>
        </div>
        <div class="col-md-2 border rounded-sm border-corner">
          <img src="Web/mico.png" class="mx-auto d-block mt-5" alt="" />
          <h6 class="offset-3 mt-3">Laboratories</h6>
        </div>
        <div class="col-md-2 border rounded-sm border-corner">
          <img src="Web/x-ray.png" class="mx-auto d-block mt-5" alt="" />
          <h6 class="offset-3 mt-3">x-ray centers</h6>
        </div>
        <div class="col-md-2 border rounded-sm border-corner">
          <img src="Web/hospital.png" class="mx-auto d-block mt-5" alt="" />
          <h6 class="offset-3 mt-3">Hospitals</h6>
        </div>
        <div class="col-md-2 border rounded-sm border-corner">
          <img src="Web/Path 202.png" class="mx-auto d-block mt-5" alt="" />
          <h6 class="offset-3 mt-3">pharmasy</h6>
        </div>
        <div class="col-md-1">
          <img src="Web/View other.png" class="" alt="" />
        </div>
      </div>
      <div class="row head">
        <h3 class="font-b">Recommended <span class="head2">Hospitals</span></h3>
      </div>
      <div class="content">
        <div class="row">
          <div class="card col-3 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
            </div>
          </div>
          <div class="card col-3 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
            </div>
          </div>
          <div class="card col-3 hospital">
            <img class="card-img-top" src="Web/hos.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Cairo,ain shams</h5>
              <p class="card-text">Some</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-8">
          <img src="Web/nurs.png" class="w-100" alt="" />
        </div>
        <div class="col-4">
          <p class="nur"></p>
          <h2>Why You Should</h2>
          <br />
          <h3>choose us</h3>
          <br />
          <h6 class="parg">
            There are many variations of passages of Lorem Ipsum available, some
            form, by injected humour.
          </h6>
          <br /><br />
          <h6 class="parg">-24000+ Online Course</h6>
          <h6 class="parg">-Expert Instruction</h6>
          <h6 class="parg">-Unlimited Access</h6>
          <h6 class="parg">-Comfortable Prices</h6>
          <h6 class="parg">-Free 2 Month Trail</h6>
          <h6 class="parg">-Review System</h6>
        </div>
        <div class="row head">
          <h3>
            Top Rated <span class="head2">doctors</span>
            <img
              src="Web/assest.png"
              class="offset-md-12"
              alt=""
            />
          </h3>
        </div>
        <div class="row">
          <div class="col-md-2 hospital">
            <img src="Web/11.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/14.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/13.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/12.png" class="doctor" alt="" />
          </div>
          <div class="col-md-2 hospital">
            <img src="Web/20.png" class="doctor" alt="" />
          </div>
        </div>
      </div>
      <div class="row head">
        <h3 class="feedback">Enroll Student's Feedback</h3>
        <input type="submit" value="view more" class="offset-12 view" />
      </div>
      <br />
      <div class="row offset-md-2">
        <div class="col-6">
          <h6 class="paragraph-news">
            It has survived not only five centuries, but also the leap into
          </h6>
          <h6 class="paragraph-news">
            electronic typesetting, remaining essentially unchanged. It was
          </h6>
          <h6 class="paragraph-news offset-md-1">
            popularised in the 1960s with the race.
          </h6>
          <br />
          <img src="Web/gray.png" class="offset-md-3" alt="" />
          <br />
          <h6 class="offset-md-2">Amanda Jackson</h6>
          <h6 class="paragraph-news offset-md-2">CEO, NRD Group</h6>
        </div>
        <div class="col-6">
          <h6 class="paragraph-news">
            It has survived not only five centuries, but also the leap into
          </h6>
          <h6 class="paragraph-news">
            electronic typesetting, remaining essentially unchanged. It was
          </h6>
          <h6 class="paragraph-news offset-md-1">
            popularised in the 1960s with the race.
          </h6>
          <br />
          <img src="Web/gray.png" class="offset-md-3" alt="" />
          <br />
          <h6 class="offset-md-2">Amanda Jackson</h6>
          <h6 class="paragraph-news offset-md-2">CEO, NRD Group</h6>
        </div>
      </div>
      <br />
      <br />
      <div class="paragraph-news offset-md-3">
        <h3 class="offset-md-1">To Get Latest News & Further Update</h3>
        <h3 class="offset-md-2">Subscribe Our Newsletter</h3>
      </div>
      <div >
        <button type="button" class="btn btn-primary rounded">Primary</button>
      </div>
    </div>
    <treat-footer></treat-footer>
  </div>
</template>