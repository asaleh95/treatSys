
<template>
  <div class="row">
    <div class="col-md-4 pl-5 pt-5">
      <h1 class="logi">SIGN up</h1>
      <br>
      <h4>Register new account</h4>
      <br>
      <p class="font-b">
        There are many variations of passages of Lorem Ipsum available, some
        form .
      </p>
      <form action="">
        <input
          type="text"
          class="form-control-lg input font-b"
          placeholder="Email Address"
        />
        <div>
          <input
            type="password"
            class="form-control-lg input font-b"
            placeholder="Password"
          />
          <!-- <span class="input-icon"><i class="fa fa-eye info"></i></span> -->
        </div>
		<div>
          <input
            type="password"
            class="form-control-lg input font-b"
            placeholder="Re-Password"
          />
          <!-- <span class="input-icon"><i class="fa fa-eye info"></i></span> -->
        </div>
		<div>
          <input
            type="text"
            class="form-control-lg input font-b"
            placeholder="Password"
          />
          
          <!-- <span class="input-icon"><i>+966</i></span> -->
          
        </div>

      <br>
        <div class="row">
          <!-- <input type="checkbox"> -->
          <input type="checkbox" name="thing" value="valuable" id="thing" />
          <label for="thing" class="ml-3"></label>
          <Span class="ml-2 mt-n1 font-b">i agree to the terms & conditions and privacy policy</Span>
        </div>
        <br>
        <button type="button" class="submit text-white text-white font-weight-bold">Sign up</button>
      </form>
      <br>
      <p class="text-muted text-center font-b">
         have an account <a href="#"> sign in</a>
      </p>
    </div>
    <div class="col-md-8">
      <img
        src="/Web/5.png"
        class="img-fluid w-100 back-color"
        alt="Cinque Terre"
      />
      <img
        src="/Web/55.png"
        class="topleft"
        style="width: 82%"
        alt="over-image"
      />
      <div>
        <h1 class="center">We Trust</h1>
        <h1 class="center text-t7t">We Care</h1>
      </div>
    </div>
  </div>
</template>