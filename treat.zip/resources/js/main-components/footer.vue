<template>
  <div>
    <footer class="py-5 footer-b">
      <div class="row marg">
        <div class="col-12 col-md">
          <img src="Web/treat.png" alt="" />
        </div>
        <div class="col-6 col-md text-white">
          <h5>Commuinity</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-white" href="#">Create Account </a></li>
            <li><a class="text-white" href="#">Go to Premium </a></li>
            <li><a class="text-white" href="#">Prefer A Friend </a></li>
            <li><a class="text-white" href="#">Get Coupon Code</a></li>
          </ul>
        </div>
        <div class="col-6 col-md text-white">
          <h5>Support</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-white" href="#">Terms Condition </a></li>
            <li><a class="text-white" href="#">Privacy & Policy </a></li>
            <li><a class="text-white" href="#">Copyright Issue </a></li>
            <li><a class="text-white" href="#">Get Help</a></li>
          </ul>
        </div>
        <div class="col-6 col-md text-white">
          <h5>Join Us</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-white" href="#">Become Teacher </a></li>
            <li><a class="text-white" href="#">Become Student </a></li>
            <li><a class="text-white" href="#">Become Both </a></li>
            <li><a class="text-white" href="#">Partnership</a></li>
          </ul>
        </div>
        <div class="col-6 col-md text-white">
          <h5>Download App</h5>
          <ul class="list-unstyled text-small">
            <li>
              <a
                class="text-white btn btn-info bg-white text-info col-md-8 mb-2"
                href="#"
                >Apple IOs</a
              >
            </li>
            <li>
              <a
                class=" h1 text-white btn btn-info bg-white text-info col-md-8"
                href="#"
                >Google Play</a
              >
            </li>
          </ul>
        </div>
      </div>
    </footer>
    <div class="row">
      <small class="d-block mb-3 text-muted offset-md-2"
        >&copy; Copyright © 2010-2019 Pro.skill</small
      >
      <small class="d-block mb-3 text-muted offset-md-6">Go to To</small>
    </div>
  </div>
</template>