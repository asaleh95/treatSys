<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WorkingHourController extends Controller
{
    //
}
